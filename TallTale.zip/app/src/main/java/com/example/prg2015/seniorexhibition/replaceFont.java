package com.example.prg2015.seniorexhibition;

import android.content.Context;
import android.graphics.Typeface;

import java.lang.reflect.Field;

/**
 * Created by Fayyaadh on 4/13/2015.
 */

public class replaceFont {
    public static void replaceDefaultFont(Context context, String nameOfFontBeingReplaced, String nameOfFontInAssets){
        Typeface customFontTypeface = Typeface.createFromAsset(context.getAssets(), nameOfFontInAssets);
        ReplaceFont(nameOfFontBeingReplaced, customFontTypeface);
    }

    private static void ReplaceFont(String nameOfFontBeingReplaced, Typeface customFontTypeface) {
        try {
            Field myField = Typeface.class.getDeclaredField(nameOfFontBeingReplaced);
            myField.setAccessible(true);
            myField.set(null, customFontTypeface);
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }

    }
}