package com.example.prg2015.seniorexhibition;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;


public class wiz_choices extends Activity implements OnItemSelectedListener{

    public static String professor = "";
    public static String spell = "";
    public static int noun = 0;
    public static int anibody = 0;
    public static String verbText = "";
    public static int legend = 0;
    public static int food = 0;
    public static String tv = "";
    public static int adj = 0;
    public static int verb = 0;
    public static String evil = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wiz_choices);

        Typeface changeFont = Typeface.createFromAsset(getAssets(),"Sanchez-Regular.ttf");
        Button butt = (Button) findViewById(R.id.button4);
        butt.setTypeface(changeFont);

        Spinner nounSpinner = (Spinner) findViewById(R.id.noun_spinner);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.noun_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        nounSpinner.setAdapter(adapter);
        nounSpinner.setOnItemSelectedListener(this);

        Spinner aniSpinner = (Spinner) findViewById(R.id.anibody_spinner);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this,
                R.array.anibody_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        aniSpinner.setAdapter(adapter2);
        aniSpinner.setOnItemSelectedListener(this);

        Spinner legSpinner = (Spinner) findViewById(R.id.legendwiz_spinner);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(this,
                R.array.legendwiz_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        legSpinner.setAdapter(adapter3);
        legSpinner.setOnItemSelectedListener(this);

        Spinner foodSpinner = (Spinner) findViewById(R.id.food_spinner);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter4 = ArrayAdapter.createFromResource(this,
                R.array.food_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        foodSpinner.setAdapter(adapter4);
        foodSpinner.setOnItemSelectedListener(this);

        Spinner adjSpinner = (Spinner) findViewById(R.id.adj_spinner);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter5 = ArrayAdapter.createFromResource(this,
                R.array.adj_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        adjSpinner.setAdapter(adapter5);
        adjSpinner.setOnItemSelectedListener(this);

        Spinner verbSpinner = (Spinner) findViewById(R.id.verb_spinner);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter6 = ArrayAdapter.createFromResource(this,
                R.array.verb_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter6.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        verbSpinner.setAdapter(adapter6);
        verbSpinner.setOnItemSelectedListener(this);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {
        Spinner spinner = (Spinner) parent;
        if (spinner.getId() == R.id.noun_spinner) {
            switch (position) {
                case 0:
                    noun = 0;
                    break;
                case 1:
                    noun = 1;
                    break;
                case 2:
                    noun = 2;
                    break;
                case 3:
                    noun = 3;
                    break;
                case 4:
                    noun = 4;
                    break;
                case 5:
                    noun = 5;
                    break;
            }
        } else if (spinner.getId() == R.id.anibody_spinner) {
            switch (position) {
                case 0:
                    anibody = 0;
                    break;
                case 1:
                    anibody = 1;
                    break;
                case 2:
                    anibody = 2;
                    break;
                case 3:
                    anibody = 3;
                    break;
                case 4:
                    anibody = 4;
                    break;
                case 5:
                    anibody = 5;
                    break;
            }
        } else if (spinner.getId() == R.id.legendwiz_spinner) {
            switch (position) {
                case 0:
                    legend = 0;
                    break;
                case 1:
                    legend = 1;
                    break;
                case 2:
                    legend = 2;
                    break;
                case 3:
                    legend = 3;
                    break;
                case 4:
                    legend = 4;
                    break;
            }
        }
        else if(spinner.getId() == R.id.food_spinner)
        {
            switch (position) {
                case 0:
                    food = 0;
                    break;
                case 1:
                    food = 1;
                    break;
                case 2:
                    food = 2;
                    break;
                case 3:
                    food = 3;
                    break;
                case 4:
                    food = 4;
                    break;
            }
        }
        else if(spinner.getId() == R.id.adj_spinner)
        {
            switch (position) {
                case 0:
                    adj = 0;
                    break;
                case 1:
                    adj = 1;
                    break;
                case 2:
                    adj = 2;
                    break;
                case 3:
                    adj = 3;
                    break;
                case 4:
                    adj = 4;
                    break;
            }
        }
        else if(spinner.getId() == R.id.verb_spinner)
        {
            switch (position) {
                case 0:
                    verb = 0;
                    break;
                case 1:
                    verb = 1;
                    break;
                case 2:
                    verb = 2;
                    break;
                case 3:
                    verb = 3;
                    break;
                case 4:
                    verb = 4;
                    break;
                case 5:
                    verb = 5;
                    break;
            }
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        // Another interface callback
    }

    public void onClickVid(View v){
        EditText profName = (EditText) findViewById(R.id.profname);
        professor = profName.getText().toString();

        EditText spellName = (EditText) findViewById(R.id.spellname);
        spell = spellName.getText().toString();

        EditText verb = (EditText) findViewById(R.id.verbEdit);
        verbText = verb.getText().toString();

        EditText television = (EditText) findViewById(R.id.tvEdit);
        tv = television.getText().toString();

        EditText evil_wizard = (EditText) findViewById(R.id.evilWizard);
        evil = evil_wizard.getText().toString();

        Intent myIntent = new Intent(wiz_choices.this, wizardWorld.class);
        //myIntent.putExtra("key", value); //Optional parameters
        wiz_choices.this.startActivity(myIntent);
        // Do something in response to button click */
    }
}