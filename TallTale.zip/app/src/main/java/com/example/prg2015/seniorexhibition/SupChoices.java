package com.example.prg2015.seniorexhibition;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class SupChoices extends Activity {

    public static int supadj1 = 0;
    public static int supnoun1 = 0;
    public static int supadj2 = 0;
    public static int supverb1 = 0;
    public static String supnoun2 = "";
    public static String villain = "";
    public static int villainpow = 0;
    public static int supverb2 = 0;
    public static String hero = "";
    public static String power1 = "";
    public static int supadj3 = 0;
    public static int supverb3 = 0;
    public static int supverb4 = 0;
    public static String heroWeapon = "";
    public static String ultiMove = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sup_choices);

        Typeface changeFont = Typeface.createFromAsset(getAssets(),"Sanchez-Regular.ttf");
        Button butt = (Button) findViewById(R.id.button);
        butt.setTypeface(changeFont);

        RadioGroup supadj1 = (RadioGroup) findViewById(R.id.radioGroup1);
        supadj1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener(){
            public void onCheckedChanged (RadioGroup radioGroup, int checkedId) {
                RadioButton answer1 = (RadioButton) findViewById(R.id.hot);
                RadioButton answer2 = (RadioButton) findViewById(R.id.cold);
                RadioButton answer3 = (RadioButton) findViewById(R.id.stormy);
                RadioButton answer4 = (RadioButton) findViewById(R.id.pretty);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    // onClicks for the 1st adjective
        public void onClickHot(View v){
            supadj1 = 1;
        }
        public void onClickCold(View v){
            supadj1 = 2;
        }
        public void onClickSmelly(View v){
            supadj1 = 3;
        }
        public void onClickPretty(View v){
            supadj1 = 4;
        }
    // End of onClicks for the 1st adjective

    // onClicks for the 1st noun
        public void onClickJohn(View v){
            supnoun1 = 1;
        }
        public void onClickJacob(View v){
            supnoun1 = 2;
        }
        public void onClickJude(View v){
            supnoun1 = 3;
        }
        public void onClickJen(View v){
            supnoun1 = 4;
        }
    // End of onClicks for the 1st noun

    // onClicks for the 2nd adjective
        public void onClickDamp(View v){
            supadj2 = 1;
        }
        public void onClickScary(View v){
            supadj2 = 2;
        }
        public void onClickCrazy(View v){
            supadj2 = 3;
        }
        public void onClickStrange(View v){
            supadj2 = 4;
        }
    // End of onClicks for the 2nd adjective

    // onClicks for the 1st verb
        public void onClickThink(View v){
            supverb1 = 1;
        }
        public void onClickSweat(View v){
            supverb1 = 2;
        }
        public void onClickScream(View v){
            supverb1 = 3;
        }
        public void onClickPant(View v){
            supverb1 = 4;
        }
    // End of onClicks for the 1st verb

    // onClicks for the Villain's Superpower Name
        public void onClickConfetti(View v){
            villainpow = 1;
        }
        public void onClickLemons(View v){
            villainpow = 2;
        }
        public void onClickPillows(View v){
            villainpow = 3;
        }
        public void onClickMonkeys(View v){
            villainpow = 4;
        }
    // End of onClicks for the Villain's Superpower Name

    // onClicks for the 2nd verb
        public void onClickFight(View v){
            supverb2 = 1;
        }
        public void onClickRun(View v){
            supverb2 = 2;
        }
        public void onClickCry(View v){
            supverb2 = 3;
        }
        public void onClickHandstand(View v){
            supverb2 = 4;
        }
    // End of onClicks for the 2nd verb

    // onClicks for the 3rd adjective
        public void onClickEpic(View v){
            supadj3 = 1;
        }
        public void onClickAmazing(View v){
            supadj3 = 2;
        }
        public void onClickAppropriate(View v){
            supadj3 = 3;
        }
        public void onClickEverlasting(View v){
            supadj3 = 4;
        }
    // End of onClicks for the 3rd adjective

    // onClicks for the 3rd verb
        public void onClickPunched(View v){
            supverb3 = 1;
        }
        public void onClickKicked(View v){
            supverb3 = 2;
        }
        public void onClickThrew(View v){
            supverb3 = 3;
        }
        public void onClickPushed(View v){
            supverb3 = 4;
        }
    // End of onClicks for the 3rd verb

    // onClicks for the 3rd verb
        public void onClickStare(View v){
            supverb4 = 1;
        }
        public void onClickPee(View v){
            supverb4 = 2;
        }
        public void onClickFlip(View v){
            supverb4 = 3;
        }
        public void onClickSmell(View v){
            supverb4 = 4;
        }
    // End of onClicks for the 3rd verb

    public void onClickNext(View v){
        /* Strings are assigned to EditTexts here, since user calls this method
        when clicking on button to create next activity */
        EditText noun2 = (EditText) findViewById(R.id.editText1);
        supnoun2 = noun2.getText().toString();

        EditText villainEdit = (EditText) findViewById(R.id.editText2);
        villain = villainEdit.getText().toString();

        EditText heroEdit = (EditText) findViewById(R.id.editText3);
        hero = heroEdit.getText().toString();

        EditText heroPower1 = (EditText) findViewById(R.id.editText4);
        power1 = heroPower1.getText().toString();

        EditText weapon = (EditText) findViewById(R.id.editText5);
        heroWeapon = weapon.getText().toString();

        EditText finisher = (EditText) findViewById(R.id.editText6);
        ultiMove = finisher.getText().toString();

        Intent myIntent = new Intent(SupChoices.this, Superheroes.class);
        //myIntent.putExtra("key", value); //Optional parameters
        SupChoices.this.startActivity(myIntent);
        // Do something in response to button click */
    }

}