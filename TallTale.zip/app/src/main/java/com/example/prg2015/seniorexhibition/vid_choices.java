package com.example.prg2015.seniorexhibition;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.AdapterView.OnItemSelectedListener;


public class vid_choices extends Activity implements OnItemSelectedListener{

    public static int gconsole = 0;
    public static String furnText = "";
    public static String game1 = "";
    public static String game2 = "";
    public static String game3 = "";
    public static String game4 = "";
    public static int hilarious = 0;
    public static String storyMiss = "";
    public static int objectives = 0;
    public static int teammates = 0;
    public static String bossName = "";
    public static int weapon = 0;
    public static int verb1 = 0;
    public static int verb2 = 0;
    public static int bodyPart = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vid_choices);

        Typeface changeFont = Typeface.createFromAsset(getAssets(),"Sanchez-Regular.ttf");
        Button butt = (Button) findViewById(R.id.button3);
        butt.setTypeface(changeFont);

        Spinner gconsoleSpinner = (Spinner) findViewById(R.id.gconsole_spinner);
        // Create an ArrayAdapter using the string array and a default spinner layout
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.gconsole_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
            gconsoleSpinner.setAdapter(adapter);
            gconsoleSpinner.setOnItemSelectedListener(this);

        Spinner hilariousSpinner = (Spinner) findViewById(R.id.hilarious_spinner);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this,
                R.array.hilarious_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        hilariousSpinner.setAdapter(adapter2);
        hilariousSpinner.setOnItemSelectedListener(this);

        Spinner objectivesSpinner = (Spinner) findViewById(R.id.objectives_spinner);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(this,
                R.array.objectives_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        objectivesSpinner.setAdapter(adapter3);
        objectivesSpinner.setOnItemSelectedListener(this);

        Spinner teamSpinner = (Spinner) findViewById(R.id.team_spinner);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter4 = ArrayAdapter.createFromResource(this,
                R.array.team_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        teamSpinner.setAdapter(adapter4);
        teamSpinner.setOnItemSelectedListener(this);

        Spinner weaponSpinner = (Spinner) findViewById(R.id.weapon_spinner);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter5 = ArrayAdapter.createFromResource(this,
                R.array.weapon_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        weaponSpinner.setAdapter(adapter5);
        weaponSpinner.setOnItemSelectedListener(this);

        Spinner verb1Spinner = (Spinner) findViewById(R.id.verb1_spinner);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter6 = ArrayAdapter.createFromResource(this,
                R.array.verb1_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter6.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        verb1Spinner.setAdapter(adapter6);
        verb1Spinner.setOnItemSelectedListener(this);

        Spinner verb2Spinner = (Spinner) findViewById(R.id.verb2_spinner);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter7 = ArrayAdapter.createFromResource(this,
                R.array.verb2_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter7.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        verb2Spinner.setAdapter(adapter7);
        verb2Spinner.setOnItemSelectedListener(this);

        Spinner bodyPartSpinner = (Spinner) findViewById(R.id.bodypart_spinner);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter8 = ArrayAdapter.createFromResource(this,
                R.array.bodypart_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter8.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        bodyPartSpinner.setAdapter(adapter8);
        bodyPartSpinner.setOnItemSelectedListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {
        Spinner spinner = (Spinner) parent;
        if(spinner.getId() == R.id.gconsole_spinner)
        {
            switch (position) {
                case 0:
                    gconsole = 0;
                    break;
                case 1:
                    gconsole = 1;
                    break;
                case 2:
                    gconsole = 2;
                    break;
                case 3:
                    gconsole = 3;
                    break;
                case 4:
                    gconsole = 4;
                    break;
            }
        }
        else if(spinner.getId() == R.id.hilarious_spinner)
        {
            switch (position) {
                case 0:
                    hilarious = 0;
                    break;
                case 1:
                    hilarious = 1;
                    break;
                case 2:
                    hilarious = 2;
                    break;
                case 3:
                    hilarious = 3;
                    break;
                case 4:
                    hilarious = 4;
                    break;
            }
        }
        else if(spinner.getId() == R.id.objectives_spinner)
        {
            switch (position) {
                case 0:
                    objectives = 0;
                    break;
                case 1:
                    objectives = 1;
                    break;
                case 2:
                    objectives = 2;
                    break;
                case 3:
                    objectives = 3;
                    break;
                case 4:
                    objectives = 4;
                    break;
            }
        }
        else if(spinner.getId() == R.id.team_spinner)
        {
            switch (position) {
                case 0:
                    teammates = 0;
                    break;
                case 1:
                    teammates = 1;
                    break;
                case 2:
                    teammates = 2;
                    break;
                case 3:
                    teammates = 3;
                    break;
                case 4:
                    teammates = 4;
                    break;
            }
        }
        else if(spinner.getId() == R.id.weapon_spinner)
        {
            switch (position) {
                case 0:
                    weapon = 0;
                    break;
                case 1:
                    weapon = 1;
                    break;
                case 2:
                    weapon = 2;
                    break;
                case 3:
                    weapon = 3;
                    break;
                case 4:
                    weapon = 4;
                    break;
            }
        }
        else if(spinner.getId() == R.id.verb1_spinner)
        {
            switch (position) {
                case 0:
                    verb1 = 0;
                    break;
                case 1:
                    verb1 = 1;
                    break;
                case 2:
                    verb1 = 2;
                    break;
                case 3:
                    verb1 = 3;
                    break;
                case 4:
                    verb1 = 4;
                    break;
            }
        }
        else if(spinner.getId() == R.id.verb2_spinner)
        {
            switch (position) {
                case 0:
                    verb2 = 0;
                    break;
                case 1:
                    verb2 = 1;
                    break;
                case 2:
                    verb2 = 2;
                    break;
                case 3:
                    verb2 = 3;
                    break;
                case 4:
                    verb2 = 4;
                    break;
            }
        }
        else if(spinner.getId() == R.id.bodypart_spinner)
        {
            switch (position) {
                case 0:
                    bodyPart = 0;
                    break;
                case 1:
                    bodyPart = 1;
                    break;
                case 2:
                    bodyPart = 2;
                    break;
                case 3:
                    bodyPart = 3;
                    break;
                case 4:
                    bodyPart = 4;
                    break;
            }
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        // Another interface callback
    }

    public void onClickVid(View v){
        EditText furniture = (EditText) findViewById(R.id.furnitureEdit);
        furnText = furniture.getText().toString();

        EditText gamen1 = (EditText) findViewById(R.id.gamename1);
        game1 = gamen1.getText().toString();

        EditText gamen2 = (EditText) findViewById(R.id.gamename2);
        game2 = gamen2.getText().toString();

        EditText gamen3 = (EditText) findViewById(R.id.gamename3);
        game3 = gamen3.getText().toString();

        EditText gamen4 = (EditText) findViewById(R.id.gamename4);
        game4 = gamen4.getText().toString();

        EditText story_mission = (EditText) findViewById(R.id.storyMission);
        storyMiss = story_mission.getText().toString();

        EditText boss_Name = (EditText) findViewById(R.id.boss);
        bossName = boss_Name.getText().toString();

        Intent myIntent = new Intent(vid_choices.this, Videogame.class);
        //myIntent.putExtra("key", value); //Optional parameters
        vid_choices.this.startActivity(myIntent);
        // Do something in response to button click */
    }
}