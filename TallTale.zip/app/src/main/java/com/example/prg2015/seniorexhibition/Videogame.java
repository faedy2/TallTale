package com.example.prg2015.seniorexhibition;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;


public class Videogame extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_videogame);

        TextView pageStory = (TextView) findViewById(R.id.textView2);

        String gconsole="BLANK";
        String hilarious="BLANK";
        String objectives="BLANK";
        String team="BLANK";
        String weapon="BLANK";
        String verb1="BLANK";
        String verb2="BLANK";
        String bodypart="BLANK";

        // Code for Game Console
            if(vid_choices.gconsole == 1){
                gconsole="Xbox One";
            }
            if(vid_choices.gconsole == 2){
                gconsole="Playstation 4";
            }
            if(vid_choices.gconsole == 3){
                gconsole="Nintendo 64";
            }
            if(vid_choices.gconsole == 4){
                gconsole="Dreamcast";
            }
        // End of code for Game Console

        // Code for bedroom furniture
            if(vid_choices.furnText.equalsIgnoreCase("") ){
                vid_choices.furnText="BLANK";
            }
        // End of code for bedroom furniture

        // Code for 1st game
            if(vid_choices.game1.equalsIgnoreCase("") ){
                vid_choices.game1="BLANK";
            }
        // End of code for 1st game

        // Code for 2nd game
            if(vid_choices.game2.equalsIgnoreCase("") ){
                vid_choices.game2="BLANK";
            }
        // End of code for 2nd game

        // Code for 3rd game
            if(vid_choices.game3.equalsIgnoreCase("") ){
                vid_choices.game3="BLANK";
            }
        // End of code for 3rd game

        // Code for 4th game
            if(vid_choices.game4.equalsIgnoreCase("") ){
                vid_choices.game4="BLANK";
            }
        // End of code for 4th game

        // Code for hilarious game scenario
            if(vid_choices.hilarious == 1){
                hilarious="running from cops";
            }
            if(vid_choices.hilarious == 2){
                hilarious="creating a weapon";
            }
            if(vid_choices.hilarious == 3){
                hilarious="fighting a boss";
            }
            if(vid_choices.hilarious == 4){
                hilarious="typing an essay";
            }
        // End of code for hilarious game scenario

        // Code for 4th game
            if(vid_choices.storyMiss.equalsIgnoreCase("") ){
                vid_choices.storyMiss="BLANK";
            }
        // End of code for 4th game

        // Code for mission objective
            if(vid_choices.objectives == 1){
                objectives="finish the mission";
            }
            if(vid_choices.objectives == 2){
                objectives="save the queen";
            }
            if(vid_choices.objectives == 3){
                objectives="win the title";
            }
            if(vid_choices.objectives == 4){
                objectives="fly to space";
            }
        // End of code for mission objective

        // Code for teammates
            if(vid_choices.teammates == 1){
                team="Mario, Link, and Kirby";
            }
            if(vid_choices.teammates == 2){
                team="Master Chief, Kratos, and Solid Snake";
            }
            if(vid_choices.teammates == 3){
                team="Sly Cooper, Crash Bandicoot, and Spyro";
            }
            if(vid_choices.teammates == 4){
                team="Naruto, Fox McCloud, and Sonic";
            }
        // End of code for teammates

        // Code for boss name
        if(vid_choices.bossName.equalsIgnoreCase("") ){
            vid_choices.bossName="BLANK";
        }
        // End of code for boss name

        // Code for weapon
            if(vid_choices.weapon == 1){
                weapon="Flaming Axe";
            }
            if(vid_choices.weapon == 2){
                weapon="High Heel";
            }
            if(vid_choices.weapon == 3){
                weapon="Bunny Cannon";
            }
            if(vid_choices.weapon == 4){
                weapon="Sock Monkey";
            }
        // End of code for weapon

        // Code for verb 1
            if(vid_choices.verb1 == 1){
                verb1="cried";
            }
            if(vid_choices.verb1 == 2){
                verb1="sat";
            }
            if(vid_choices.verb1 == 3){
                verb1="meditated";
            }
            if(vid_choices.verb1 == 4){
                verb1="sneezed";
            }
        // End of code verb 1

        // Code for verb 2
            if(vid_choices.verb2 == 1){
                verb2="super punched";
            }
            if(vid_choices.verb2 == 2){
                verb2="butterfly kicked";
            }
            if(vid_choices.verb2 == 3){
                verb2="elbowed";
            }
            if(vid_choices.verb2 == 4){
                verb2="pushed";
            }
        // End of code for verb 2

        // Code for body part
            if(vid_choices.bodyPart == 1){
                bodypart="spleen";
            }
            if(vid_choices.bodyPart == 2){
                bodypart="kidney";
            }
            if(vid_choices.bodyPart == 3){
                bodypart="throat";
            }
            if(vid_choices.bodyPart == 4){
                bodypart="face";
            }
        // End of code for body part

        String story = "             I came home from school on an exhausting Friday of classwork ready to do nothing but sleep. My teacher didn’t give us any homework over the weekend, so I was relieved. As I lay down on my bed ready to nap, I couldn’t help but notice my [" +gconsole +"] sitting on my [" +vid_choices.furnText+"] collecting dust.\n" +
                "             \n             The only thing I could think of in that moment was “It’s so tempting to play!”. After grabbing my [" +gconsole +"], I couldn’t decide what game to put in, my choices were [" +vid_choices.game1+"], [" +vid_choices.game2+"], [" +vid_choices.game3+"], or [" +vid_choices.game4+"]. [" +vid_choices.game3+"] was obviously the best choice.\n" +
                "             \n             The game slid into my [" +gconsole +"] and loaded back to where I was previously. The last thing that I could recall was that I was [" +hilarious +"] at who knows where! Many hours of addicting gameplay later, I had decided to play one of the story missions, it was called “[" +vid_choices.storyMiss +"]”.\n" +
                "             \n             My objective was to [" +objectives +"] without dying or else I had to reload my last save. I noticed something strange, new characters were being transported into the game! They were [" +team +"].\n" +
                "             \n             I couldn’t tell if we were working together or if we were going to fight one another, but after taking a good look at them I knew that they were on my side. [" +team +"] fought off 100 bad guys while I raced through the last objective, reaching the final boss fight.\n" +
                "             \n             This was a tough boss, its name was “[" +vid_choices.bossName+"]”! I was forced to bring out my secret weapon. My [" +weapon +"] swung at it with all its strength and did nothing. [" +vid_choices.bossName+"] looked at me and [" +verb1+ "] until my friends showed up!\n" +
                "             \n             [" +team +"] [" +verb2 +"] it in the [" +bodypart +"] causing an earthquake and obliterating it. I guess that they found its weak spot.\n" +
                "             \n             After beating it, they all smiled and nodded at me with pride.\n" +
                "             \n             The game was over and although I felt sad, I was happy to help kick some butt with my childhood heroes.";

        pageStory.setText(story);
    } // end of onCreate

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}