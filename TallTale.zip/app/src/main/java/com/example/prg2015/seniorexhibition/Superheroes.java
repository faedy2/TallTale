package com.example.prg2015.seniorexhibition;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;


public class Superheroes extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_superheroes);

        TextView pageStory = (TextView) findViewById(R.id.textView);

        String supadj1="BLANK";
        String supnoun1="BLANK";
        String supadj2="BLANK";
        String supverb1="BLANK";
        String villainpow="BLANK";
        String supverb2="BLANK";
        String supadj3="BLANK";
        String supverb3="BLANK";
        String supverb4="BLANK";

        // Code for 1st adjective
            if(SupChoices.supadj1 == 1){
                supadj1="hot";
            }
            if(SupChoices.supadj1 == 2){
                supadj1="cold";
            }
            if(SupChoices.supadj1 == 3){
                supadj1="smelly";
            }
            if(SupChoices.supadj1 == 4){
                supadj1="pretty";
            }
        // End of code for 1st adjective

        // Code for 1st noun
            if(SupChoices.supnoun1 == 1){
                supnoun1="John";
            }
            if(SupChoices.supnoun1 == 2){
                supnoun1="Jacob";
            }
            if(SupChoices.supnoun1 == 3){
                supnoun1="Jude";
            }
            if(SupChoices.supnoun1 == 4){
                supnoun1="Jen";
            }
        // End of code for 1st noun

        // Code for 2nd adjective
            if(SupChoices.supadj2 == 1){
                supadj2="damp";
            }
            if(SupChoices.supadj2 == 2){
                supadj2="scary";
            }
            if(SupChoices.supadj2 == 3){
                supadj2="crazy";
            }
            if(SupChoices.supadj2 == 4){
                supadj2="strange";
            }
        // End of code for 2nd adjective

        // Code for 1st verb
            if(SupChoices.supverb1 == 1){
                supverb1="think";
            }
            if(SupChoices.supverb1 == 2){
                supverb1="sweat";
            }
            if(SupChoices.supverb1 == 3){
                supverb1="scream";
            }
            if(SupChoices.supverb1 == 4){
                supverb1="pant";
            }
        // End of code for 1st verb

        // Code for 2nd noun
             if(SupChoices.supnoun2.equalsIgnoreCase("") ){
                SupChoices.supnoun2="BLANK";
             }
        // End of code for 2nd noun

        //   Code for villain string
            if(SupChoices.villain.equalsIgnoreCase("") ){
                SupChoices.villain="BLANK";
            }
        //   End of code for villain string

        // Code for villain power
            if(SupChoices.villainpow == 1){
                villainpow="Confetti";
            }
            if(SupChoices.villainpow == 2){
                villainpow="Lemons";
            }
            if(SupChoices.villainpow == 3){
                villainpow="Pillows";
            }
            if(SupChoices.villainpow == 4){
                villainpow="Monkeys";
            }
        // End of code for villain power

        // Code for 2nd verb
            if(SupChoices.supverb2 == 1){
                supverb2="fight";
            }
            if(SupChoices.supverb2 == 2){
                supverb2="run";
            }
            if(SupChoices.supverb2 == 3){
                supverb2="cry";
            }
            if(SupChoices.supverb2 == 4){
                supverb2="handstand";
            }
        // End of code for 2nd verb

        // Code for hero string
            if(SupChoices.hero.equalsIgnoreCase("") ){
                SupChoices.hero="BLANK";
            }
        // End of code for hero string

        // Code for hero string
            if(SupChoices.power1.equalsIgnoreCase("") ){
                SupChoices.power1="BLANK";
            }
        // End of code for hero string

        // Code for 3rd adjective
            if(SupChoices.supadj3 == 1){
                supadj3="epic";
            }
            if(SupChoices.supadj3 == 2){
                supadj3="amazing";
            }
            if(SupChoices.supadj3 == 3){
                supadj3="appropriate";
            }
            if(SupChoices.supadj3 == 4){
                supadj3="everlasting";
            }
        // End of code for 3rd adjective

        // Code for 3rd verb
            if(SupChoices.supverb3 == 1){
                supverb3="punched";
            }
            if(SupChoices.supverb3 == 2){
                supverb3="kicked";
            }
            if(SupChoices.supverb3 == 3){
                supverb3="threw";
            }
            if(SupChoices.supverb3 == 4){
                supverb3="pushed";
            }
        // End of code for 3rd verb

        // Code for 4th verb
            if(SupChoices.supverb4 == 1){
                supverb4="stare";
            }
            if(SupChoices.supverb4 == 2){
                supverb4="pee";
            }
            if(SupChoices.supverb4 == 3){
                supverb4="flip";
            }
            if(SupChoices.supverb4 == 4){
                supverb4="smell";
            }
        // End of code for 4th verb

        // Code for hero weapon string
        if(SupChoices.heroWeapon.equalsIgnoreCase("") ){
            SupChoices.heroWeapon="BLANK";
        }
        // End of code for hero weapon string

        // Code for ultimate move string
        if(SupChoices.ultiMove.equalsIgnoreCase("") ){
            SupChoices.ultiMove="BLANK";
        }
        // End of code for ultimate move string

        String story = "             It’s a [" +supadj1 +"] summer’s afternoon and the sun is shining above St. [" +supnoun1 +"]’s elementary school. The day felt strangely [" +supadj2 +"] as I walked towards my classroom. One would hope that it would be a normal day of learning, but one would be wrong. Alarm bells start ringing and all the teachers lock their doors for safety.\n" +
                "             \n             I begin to [" +supverb1 +"] if I’ll ever make it home in time for my mom’s famous [" +SupChoices.supnoun2+"] sandwiches. All of a sudden the door swings open and [" +SupChoices.villain+"] storms into the room and used his power of [" +villainpow+"] to put everyone in class to sleep. As I stood up to [" +supverb2+"], I saw something in the distance and it was coming this way!\n" +
                "             \n             It was [" +SupChoices.hero+"]! After [" +SupChoices.hero+"] burst through the window yelling “Not today [" +SupChoices.villain+"]!”. [" +SupChoices.hero+"] used his special ability, [" +SupChoices.power1+"], to throw [" +SupChoices.villain+"] off his socks and through the roof!\n" +
                "             \n             I couldn’t help but run over and see the fight, one punched the other, kicks flew everywhere, an [" +supadj3 +"] fight right in front of me! Just when I thought it would never end, [" +SupChoices.villain+"] [" +supverb3 +"] [" +SupChoices.hero+"] into the ground.\n" +
                "             \n             I had to help! I ran over to [" +SupChoices.hero+"] and tried to do all that I could to assist. As I began to think the worst, [" +SupChoices.hero+"] looked and me and smiled, getting back up to face [" +SupChoices.villain+"] with confidence.\n" +
                "             \n             [" +SupChoices.hero+"] charged into [" +SupChoices.villain+"], causing me to [" +supverb4 +"] in wonderment. The fight went on for hours! Finally [" +SupChoices.villain+"] was defeated after being hit with [" +SupChoices.hero+"]’s [" +SupChoices.heroWeapon+"], [" +SupChoices.power1+"], and the [" +SupChoices.ultiMove+"].\n" +
                "             \n             Before [" +SupChoices.hero+"] was about to leave, I received a wink with a smile. Now that was a fun Monday!";

        pageStory.setText(story);

    } // end of onCreate

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}