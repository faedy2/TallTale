package com.example.prg2015.seniorexhibition;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;


public class dropDownTest extends Activity {

    String dropTest1 = "BLANK";
    String dropTest2 = "BLANK";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drop_down_test);

        TextView test1 = (TextView) findViewById(R.id.dropFill1);
        if(dropDownChoice.testInt1 == 0){
            dropTest1 = "BLANK";
        }
        if(dropDownChoice.testInt1 == 1){
            dropTest1 = "stupid";
        }
        if(dropDownChoice.testInt1 == 2){
            dropTest1 = "silly face";
        }
        if(dropDownChoice.testInt1 == 3){
            dropTest1 = "stinky butt";
        }
        if(dropDownChoice.testInt1 == 4){
            dropTest1 = "handsome devil";
        }
        String fill1 = "I'm a [" +dropTest1 +"]";
        test1.setText(fill1);

        TextView test2 = (TextView) findViewById(R.id.dropFill2);
        if(dropDownChoice.testInt2 == 0){
            dropTest2 = "BLANK";
        }
        if(dropDownChoice.testInt2 == 1){
            dropTest2 = "good";
        }
        if(dropDownChoice.testInt2 == 2){
            dropTest2 = "bad";
        }
        if(dropDownChoice.testInt2 == 3){
            dropTest2 = "smelly";
        }
        if(dropDownChoice.testInt2 == 4){
            dropTest2 = "delicious";
        }
        String fill2 = "I smell [" +dropTest2 +"]";
        test2.setText(fill2);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}