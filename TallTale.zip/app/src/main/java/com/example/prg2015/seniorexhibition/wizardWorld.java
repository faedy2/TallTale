package com.example.prg2015.seniorexhibition;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;


public class wizardWorld extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wizard_world);

        TextView pageStory = (TextView) findViewById(R.id.wizStory);

        String noun="BLANK";
        String animalBody="BLANK";
        String legendWiz="BLANK";
        String food="BLANK";
        String adj="BLANK";
        String verb="BLANK";

        // Code for professor name
            if(wiz_choices.professor.equalsIgnoreCase("") ){
                wiz_choices.professor="BLANK";
            }
        // End of code for professor name

        // Code for spell name
            if(wiz_choices.spell.equalsIgnoreCase("") ){
                wiz_choices.spell="BLANK";
            }
        // End of code for spell name

        // Code for noun
            if(wiz_choices.noun == 1){
                noun="shoes";
            }
            if(wiz_choices.noun == 2){
                noun="books";
            }
            if(wiz_choices.noun == 3){
                noun="cell phones";
            }
            if(wiz_choices.noun == 4){
                noun="trains";
            }
            if(wiz_choices.noun == 5){
                noun="homework";
            }
        // End of code for noun

        // Code for animal/body part
            if(wiz_choices.anibody == 1){
                animalBody="hair";
            }
            if(wiz_choices.anibody == 2){
                animalBody="dinosaurs";
            }
            if(wiz_choices.anibody == 3){
                animalBody="feet";
            }
            if(wiz_choices.anibody == 4){
                animalBody="cheetahs";
            }
            if(wiz_choices.anibody == 5){
                animalBody="doves";
            }
        // End of code for animal/body part

        // Code for verb
            if(wiz_choices.verbText.equalsIgnoreCase("") ){
                wiz_choices.verbText="BLANK";
            }
        // End of code for verb

        // Code for legendary wizard
            if(wiz_choices.legend == 1){
                legendWiz="Dumbledore";
            }
            if(wiz_choices.legend == 2){
                legendWiz="Gandalf";
            }
            if(wiz_choices.legend == 3){
                legendWiz="Merlin";
            }
            if(wiz_choices.legend == 4){
                legendWiz="Houdini";
            }
        // End of code for legendary wizard

        // Code for food
            if(wiz_choices.food == 1){
                food="pizza";
            }
            if(wiz_choices.food == 2){
                food="chinese food";
            }
            if(wiz_choices.food == 3){
                food="pasta";
            }
            if(wiz_choices.food == 4){
                food="rice and beans";
            }
        // End of code for food

        // Code for tv show
        if(wiz_choices.tv.equalsIgnoreCase("") ){
            wiz_choices.tv="BLANK";
        }
        // End of code for tv show

        // Code for adjective
            if(wiz_choices.adj == 1){
                adj="powerful";
            }
            if(wiz_choices.adj == 2){
                adj="evil";
            }
            if(wiz_choices.adj == 3){
                adj="amazing";
            }
            if(wiz_choices.adj == 4){
                adj="mischievous";
            }
        // End of code for adjective

        // Code for verb
            if(wiz_choices.verb == 1){
                verb="stop";
            }
            if(wiz_choices.verb == 2){
                verb="fight";
            }
            if(wiz_choices.verb == 3){
                verb="beat";
            }
            if(wiz_choices.verb == 4){
                verb="tickle";
            }
            if(wiz_choices.verb == 5){
                verb="destroy";
            }
        // End of code for verb

        // Code for evil wizard
            if(wiz_choices.evil.equalsIgnoreCase("") ){
                wiz_choices.evil="BLANK";
            }
        // End of code for evil wizard


        String story = "             Professor [" +wiz_choices.professor+"] is going to teach us a new spell today. It is called [" +wiz_choices.spell+"]. When we cast it, it will make [" +noun +"] turn into [" +animalBody +"]. This is going to be great!\n" +
                "             \n             I’m going to make the coolest thing ever happen with my spell! Ok, the instructions were to [" +wiz_choices.verbText+"] my wand, then to point it upward. Here goes nothing! [" +wiz_choices.spell+"]! I did it! This is fantastic!\n" +
                "             \n             [" +wiz_choices.professor+"] was so proud of me for following directions. Maybe someday, I can become as great as [" +legendWiz +"].\n" +
                "             \n             Now that I am one step closer to being a master wizard, I should go back to my wizard dorm and order [" +food +"] for dinner and watch my new favorite TV show, [" +wiz_choices.tv+"].\n" +
                "             \n             Tomorrow will be another amazing day of training. If I try hard enough, I can become the most [" +adj +"] wizard that there ever was!\n" +
                "             \n             No one would be able to [" +verb +"] me, not even the evil dark lord [" +wiz_choices.evil+"]. I can’t wait for another day of being amazing, especially right after eating my [" +food +"].";

        pageStory.setText(story);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}